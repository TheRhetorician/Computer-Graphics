var searchData=
[
  ['left_19',['left',['../structnode.html#af0a44f6d3fb08e7eb0f4c0900ec23e7d',1,'node']]]
];
