var searchData=
[
  ['create_52',['create',['../struct_8h.html#ad6fe1056be72df9b35c295bf9609d3a6',1,'struct.h']]]
];
