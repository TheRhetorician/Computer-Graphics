var searchData=
[
  ['vertical_5fabove_42',['vertical_above',['../All__Slopes_8h.html#aa4a6475634e8ef39ee2add15d870e915',1,'All_Slopes.h']]],
  ['vertical_5fbelow_43',['vertical_below',['../All__Slopes_8h.html#ab53d4699db6bf379a96540436f01b55c',1,'All_Slopes.h']]]
];
