var searchData=
[
  ['givecoord_14',['giveCoord',['../Height__tree_8h.html#addaa940c31906e89bd5ac5b2b9790b3c',1,'Height_tree.h']]],
  ['giveheight_15',['giveheight',['../Height__tree_8h.html#a21979504f0ace594a8e57a9487c225ae',1,'Height_tree.h']]]
];
