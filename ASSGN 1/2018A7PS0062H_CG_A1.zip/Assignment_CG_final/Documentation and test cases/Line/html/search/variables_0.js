var searchData=
[
  ['x0_28',['x0',['../main_8c.html#a97650a9c1395589a56789a90b5bf8d0c',1,'main.c']]],
  ['x1_29',['x1',['../main_8c.html#a97fcb0e1731b36905e90757f211b1340',1,'main.c']]]
];
