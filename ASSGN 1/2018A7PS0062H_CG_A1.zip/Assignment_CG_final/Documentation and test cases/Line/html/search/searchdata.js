var indexSectionsWithContent =
{
  0: "admsvxy",
  1: "adm",
  2: "dmsv",
  3: "xy"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Variables"
};

