var searchData=
[
  ['pts_34',['pts',['../calc_8h.html#a818fd2e3ca8b6ae6d58ebfc674c232be',1,'calc.h']]]
];
