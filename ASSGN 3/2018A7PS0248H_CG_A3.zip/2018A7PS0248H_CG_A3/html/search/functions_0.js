var searchData=
[
  ['closest_22',['closest',['../calc_8h.html#aaf8f91c31bbe13b6a075fce215fc1560',1,'calc.h']]]
];
