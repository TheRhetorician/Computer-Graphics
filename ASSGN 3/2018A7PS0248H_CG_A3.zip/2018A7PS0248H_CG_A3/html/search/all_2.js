var searchData=
[
  ['calc_2eh_2',['calc.h',['../calc_8h.html',1,'']]],
  ['closest_3',['closest',['../calc_8h.html#aaf8f91c31bbe13b6a075fce215fc1560',1,'calc.h']]]
];
