var searchData=
[
  ['plot_2eh_14',['plot.h',['../plot_8h.html',1,'']]],
  ['pts_15',['pts',['../calc_8h.html#a818fd2e3ca8b6ae6d58ebfc674c232be',1,'calc.h']]]
];
