var searchData=
[
  ['feat_33',['feat',['../plot_8h.html#a36e10a68b2d6ea8a743fb39cbf2388f5',1,'plot.h']]]
];
