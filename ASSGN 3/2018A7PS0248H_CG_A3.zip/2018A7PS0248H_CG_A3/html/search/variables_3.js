var searchData=
[
  ['screen_35',['screen',['../calc_8h.html#a3109b0889cec9f0de874a2bdc1f84372',1,'calc.h']]]
];
