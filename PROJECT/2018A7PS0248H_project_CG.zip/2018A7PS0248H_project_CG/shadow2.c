#include "display.h "
/* COMPUTER GRAPHICS PROJECT ON RESEARCH PAPER OF Polygon Shadow Generation

	Mudit Chaturvedi 2018A7PS0248H
	Hardik Parnami   2018A7PS0062H
	Tanay Gupta      2018AAPS0343H
*/

//Initializes 3D rendering
void initRendering() {
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_COLOR_MATERIAL);
    glEnable(GL_LIGHTING); //Enable lighting
    glEnable(GL_LIGHT0); //Enable light #0
    glEnable(GL_LIGHT1); //Enable light #1
    glEnable(GL_LIGHT2);
    glEnable(GL_NORMALIZE); //Automatically normalize normals
    //glShadeModel(GL_SMOOTH); //Enable smooth shading
}

//Called when the window is resized
void handleResize(int w, int h) {
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0, (double)w / (double)h, 1.0, 200.0);
}

int main(int argc, char** argv) {
    //Initialize GLUT
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glEnable(GL_DEPTH_TEST);
    glutInitWindowSize(800, 800);
    //Create the window
    glutCreateWindow("Room with chair and table");
    initRendering();

    //Set handler functions
    //cuboid();
    printf("ENTER 1 FOR SIMPLE CUBE\n 2 FOR SIMPLE CUBOID\n");
	printf("3 FOR CUBE WITH OBJECT TO BE HIDDEN\n 4 FOR CUBE WITH PARTIALLY VISIBLE OBJECT\n");
    
	scanf("%d",&ch); 
    
    if(ch==2)
    cuboid(); //simple cuboid
    
    work(); // calls function for clipping the scene 
    glutDisplayFunc(drawScene);
    work();
    
    glutDisplayFunc(drawScene);
    glutKeyboardFunc(handleKeypress);
    glutSpecialFunc(specialInput);
    glutReshapeFunc(handleResize);

    glutMainLoop();
}
