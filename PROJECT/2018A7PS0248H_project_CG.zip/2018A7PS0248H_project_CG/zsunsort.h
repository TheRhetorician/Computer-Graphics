#include "clipping.h"
// converts the 3D coordinates to 2D coordinates



int maximum(int i);
int minimum(int i);
void setDef();

void sort()
{
	for(int i=0;i<24;i++) //stores the original polygon into a duplicate array pt
	{
		pt[i][0]= f[i][0];
		pt[i][1]= f[i][1];
		pt[i][2]= f[i][2];
	}

// sort based on z value, the ordering of pt array
	for(int i=0;i<23;i++)
	{
		for(int j=i+1;j<24;j++)
		{
			if(pt[i][2]<pt[j][2])
			{
				int temp = pt[i][0];
				pt[i][0] = pt[j][0];
				pt[j][0] = temp;
				temp = pt[i][1];
				pt[i][1] = pt[j][1];
				pt[j][1] = temp;
				temp = pt[i][2];
				pt[i][2] = pt[j][2];
				pt[j][2] = temp;
			}
		}
	}
}

int contains(int a,int b) // check if temporary 2D array has specific elements
{
	int qwerty=0;
	for(int i=0;i<qw;i++)
	{
		if(tx[i][0]==a && tx[i][1]==b)
			qwerty = 1;
	}
	return qwerty;
}

void clock(int x1,int y1) // sorts the 2D points in clockwise manner
{
	float m[qw];
	for(int i=0;i<qw;i++)
	{
		if((tx[i][0]-x1)!=0)
		m[i] = (tx[i][1]-y1)/(tx[i][0]-x1);
		else 
		m[i]=10000000000000000;
	}
	for(int i=0;i<qw-1;i++)
	{
		for(int j=i+1;j<qw;j++)
		{
			if(m[i]<m[j])
			{
				int temp = tx[i][0];
				tx[i][0] = tx[j][0];
				tx[j][0] = temp;
				temp = tx[i][1];
				tx[i][1] = tx[j][1];
				tx[j][1] = temp;
				temp = m[i];
				m[i] = m[j];
				m[j] = temp;
			}
		}
	}
}
void suth() // calls the main clipping algorithm
{
	int z = 10;
	while(z>=(-10))
	{
	
		for(int i=0;i<24;i++)
		{
			if(pt[i][2]==z)
			{ //stores all the points having same z value into a temporary 2D array
				if(contains(pt[i][0],pt[i][1])==0)
				{
					tx[qw][0]=pt[i][0];
					tx[qw++][1]=pt[i][1];
				}
			}
		}
		int x1 = minimum(0); //gets the coordinates for the clipping window for each z value
		int x2 = maximum(0);
		int y1 = minimum(1);
		int y2 = maximum(1);
		cx[0][0]=x1,cx[0][1]=y1;  // store coordinates of clipping window in cx;
		cx[1][0]=x1,cx[1][1]=y2;
		cx[2][0]=x2,cx[2][1]=y2;
		cx[3][0]=x2,cx[3][1]=y1;
		clock(x1,y1);
		sutherlandclip(cx,tx,qw,z); //call to main clipping algorithm
		z-=20;
		setDef();// sets the temporary array to default
		qw = 0; // stores length of temporary array
		
	}
}

int maximum(int i) //returns the maximum value of parameter i in temporary array
{
	int max1 = -100000;
	for(int j=0;j<qw;j++)
	{
		if(max1<tx[j][i])
		max1 = tx[j][i];
	}
	return max1;
}

int minimum(int i) //returns the minimum value of parameter i in temporary array
{
	int min1 = 100000;
	for(int j=0;j<qw;j++)
	{
		if(min1>tx[j][i])
		min1 = tx[j][i];
	}
	return min1;
}

void setDef() // reset the temporary array for next set of points
{
	for(int i=0;i<qw;i++)
	{
		tx[i][0]=-1;
		tx[i][1]=-1;
	}
}

void work()
{ // calls to sorting function and 2D conversion function
	sort();
	suth();
}




