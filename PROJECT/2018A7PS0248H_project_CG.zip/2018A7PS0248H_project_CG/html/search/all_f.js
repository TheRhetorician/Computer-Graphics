var searchData=
[
  ['y_5fintersect_48',['y_intersect',['../clipping_8h.html#a3eda8320961cad40b9e643e441235123',1,'clipping.h']]]
];
