var searchData=
[
  ['zcord_49',['zcord',['../clipping_8h.html#aa6e3e8c56a7402fc90ed44e00138d10e',1,'clipping.h']]],
  ['zsunsort_2eh_50',['zsunsort.h',['../zsunsort_8h.html',1,'']]]
];
