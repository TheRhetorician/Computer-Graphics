var searchData=
[
  ['max_5fpoints_92',['MAX_POINTS',['../clipping_8h.html#a620372022e311eb95a5839708e6df079',1,'clipping.h']]],
  ['mode_93',['mode',['../keys_8h.html#a1ea5d0cb93f22f7d0fdf804bd68c3326',1,'keys.h']]]
];
