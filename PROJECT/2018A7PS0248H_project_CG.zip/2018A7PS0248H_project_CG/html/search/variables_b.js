var searchData=
[
  ['zcord_101',['zcord',['../clipping_8h.html#aa6e3e8c56a7402fc90ed44e00138d10e',1,'clipping.h']]]
];
