var indexSectionsWithContent =
{
  0: "acdfhiklmpqstwxyz",
  1: "cdksz",
  2: "cdhimswxy",
  3: "acfiklmpqstz"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Variables"
};

