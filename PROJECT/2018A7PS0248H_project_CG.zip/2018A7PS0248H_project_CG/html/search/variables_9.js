var searchData=
[
  ['shadow_96',['shadow',['../keys_8h.html#a109a7700b3b0513da6b06c24afb364ea',1,'keys.h']]],
  ['small_97',['small',['../keys_8h.html#a1df9b7033d7f291fb6a2b642cbf704a4',1,'keys.h']]]
];
