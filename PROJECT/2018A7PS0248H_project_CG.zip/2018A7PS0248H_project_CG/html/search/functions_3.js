var searchData=
[
  ['initrendering_65',['initRendering',['../shadow2_8c.html#a17a53fe9e683b81bdc7618f88b8b8502',1,'shadow2.c']]]
];
