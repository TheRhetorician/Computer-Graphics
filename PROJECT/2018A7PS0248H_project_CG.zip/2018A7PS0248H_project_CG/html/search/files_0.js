var searchData=
[
  ['clipping_2eh_51',['clipping.h',['../clipping_8h.html',1,'']]]
];
