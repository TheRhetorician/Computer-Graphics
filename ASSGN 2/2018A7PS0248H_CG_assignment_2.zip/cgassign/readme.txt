Please open index.html file 
inside html folder for Doxygen documentation.