var searchData=
[
  ['handlekeypress_9',['handleKeypress',['../keys_8h.html#a7fccc9dc8048323648486d3414f55394',1,'keys.h']]],
  ['handleresize_10',['handleResize',['../room_8c.html#a044dd1c2e44e0618aceda5840812afa1',1,'room.c']]]
];
