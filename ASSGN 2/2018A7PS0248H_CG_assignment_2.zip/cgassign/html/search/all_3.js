var searchData=
[
  ['initrendering_11',['initRendering',['../room_8c.html#a17a53fe9e683b81bdc7618f88b8b8502',1,'room.c']]]
];
