var searchData=
[
  ['specialinput_31',['specialInput',['../keys_8h.html#a7f1b5a7583a9943794390bab10e3f86c',1,'keys.h']]]
];
